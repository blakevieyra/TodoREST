package com.skilldistillery.todoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
