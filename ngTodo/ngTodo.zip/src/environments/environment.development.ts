export const environment = {
  baseUrl: 'http://localhost:8090/'
};
