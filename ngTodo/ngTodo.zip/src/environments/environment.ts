export const environment = {
  baseUrl: '/TodoREST/'
};
